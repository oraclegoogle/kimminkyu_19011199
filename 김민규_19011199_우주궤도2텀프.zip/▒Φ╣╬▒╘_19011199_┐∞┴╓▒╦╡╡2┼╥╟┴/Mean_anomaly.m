function M = Mean_anomaly(time_start,time_current,a,e,M0)
mu = 3.986e+5;
s = seconds(time_current-time_start);
M = M0 + sqrt(mu/a^3)*s; 
if abs(M) > pi*2
    M = rem(M,pi*2);
end
end