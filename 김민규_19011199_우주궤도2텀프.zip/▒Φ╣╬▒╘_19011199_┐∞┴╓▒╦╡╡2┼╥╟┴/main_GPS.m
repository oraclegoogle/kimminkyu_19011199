% Main Script %
clear all;
clc;

% Prompt the user to enter the start time
disp('Enter the startday information')
year = input('Enter the year: ');
month = input('Enter the month: ');
day = input('Enter the day: ');
hour = input('Enter the hour: ');
minute = input('Enter the minute: ');
second = input('Enter the second: ');

% Prompt the user to enter the groundstation and elevationmask
ground_lat = input('Enter lattitude of groundstation to degree: ');
ground_lon = input('Enter longitude of groundstation to degree: '); 
height = input('Enter height of groundstation to killometre: '); 
el_mask = input('Enter screening elevation mask to degree: '); 

% Create a datetime object for the start time
starttime = datetime(year, month, day, hour, minute, second);

% Calculate the next day by adding one day to the start time
nextday = starttime + caldays(1);

% Convert the next day to the same format as starttime
fintime = datetime(nextday);

% Parameter
load('nav.mat');
a = nav.GPS.a / 1000;  
e = nav.GPS.e;  
i = rad2deg(nav.GPS.i);  
omega = rad2deg(nav.GPS.omega); 
M0 = nav.GPS.M0; 
toc = nav.GPS.toc; 
OMEGA = rad2deg(nav.GPS.OMEGA);
TA0=M0+2*e*sin(M0);

% Time set
tdatum=datetime(toc);
t1 = datetime(starttime);
t2 = datetime(fintime); 
ttime = linspace(t1, t2, 24 * 60);

% Append matrices 
lat_geoplot = [];
lon_geoplot = []; 
az_skyplot = [];
el_skyplot = [];

% Orbit calculate
for j = 1:length(ttime)
    M = Mean_anomaly(tdatum, ttime(j), a, e, M0);
    E = Mean2Eccen(M, e);
    v = E2v(E, e);
    rangeInPQW = solveRangeInPerifocalFrame(a, e, v);
    DCM_P2I = PQW2ECI(omega, i, OMEGA);
    rangeInECI = DCM_P2I * rangeInPQW;
    DCM = ECI2ECEF_DCM(ttime(j));
    rangeInECEF = DCM * rangeInECI;
    wgs84 = wgs84Ellipsoid('kilometer');
    [lat, lon, h] = ecef2geodetic(wgs84, rangeInECEF(1), rangeInECEF(2), ...
        rangeInECEF(3), "degrees");
    lat_geoplot = [lat_geoplot, lat];
    lon_geoplot = [lon_geoplot, lon];
    [rangeInENU(1), rangeInENU(2), rangeInENU(3)] = ecef2enu(rangeInECEF(1), ...
        rangeInECEF(2), rangeInECEF(3), ground_lat, ground_lon, height, wgs84);
    rangeInENU = [rangeInENU(1); rangeInENU(2); rangeInENU(3)];
    az = azimuth(rangeInENU);
    el = elevation(rangeInENU, el_mask);
    az_skyplot = [az_skyplot, az];
    el_skyplot = [el_skyplot, el];
end

% finalesequence
geoplot(lat_geoplot, lon_geoplot, 'm-*');
figure;
skyplot(az_skyplot, el_skyplot);

%make3dplot


sampleTime = 60;
sc = satelliteScenario(starttime,fintime,sampleTime);

semiMajorAxis = a*1000;
eccentricity = e;
inclination = i;
rightAscensionOfAscendingNode = OMEGA;
argumentOfPeriapsis = omega;
trueAnomaly = v;
sat = satellite(sc,semiMajorAxis,eccentricity,inclination, ...
    rightAscensionOfAscendingNode,argumentOfPeriapsis,trueAnomaly)

show(sat)
groundTrack(sat,LeadTime=3600)

play(sc,PlaybackSpeedMultiplier=40)