function DCM=ECI2ECEF_DCM(time)
jd = juliandate(time);
thGMST = siderealTime(jd);
DCM = [cosd(thGMST) sind(thGMST) 0;
       -sind(thGMST) cosd(thGMST) 0;
       0 0 1];

end